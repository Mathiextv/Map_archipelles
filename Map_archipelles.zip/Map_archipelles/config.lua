
extraTiles = {
    [1] = {xOffset = -2, yOffset = -1, txd = "minimap_sea_Galapagous_1", txn = "minimap_sea_Galapagous_1"}, -- Galapagous Mid
    [2] = {xOffset = -3, yOffset = -1, txd = "minimap_sea_Galapagous_2", txn = "minimap_sea_Galapagous_2"}, -- Galapagous Left
    [3] = {xOffset = -2, yOffset = 0, txd = "minimap_sea_Galapagous_3", txn = "minimap_sea_Galapagous_3"}, -- Galapagous Top
}

defaultAlpha = 100
